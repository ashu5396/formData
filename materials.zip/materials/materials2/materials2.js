$(document).ready(function(){
   
    $('#close-button').click(function(){
        callToggleFunction();
       
    })
    $('#okay-button').click(function(){
       callToggleFunction();
        
    })

    var callToggleFunction=function(){
        $('#modal').toggle();
        $('#modal-overlay').toggle();
    }

    $('.button-div button').click(function(){
        $('.button-div button').removeClass('clicked');
        $(this).addClass('clicked')
    })
})