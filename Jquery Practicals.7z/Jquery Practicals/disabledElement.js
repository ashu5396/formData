$(document).ready(function(){
    $(':disabled').css('border','2px solid red')//select disabled element
    $(':enabled').css('border','2px solid green')
});
