// $(document).ready(function(){
//     $('#btn').on('click',sayHallo);
//     function sayHallo(){
//         alert('hello');
//     }
// });
$(document).ready(function(){
    $('#btn').on('click',{
        firstname:"Ashutosh",// here we are passing json data to the event handler
        lastname:"Kumar",
        company:"Capgemini"
    },sayHello);
    function sayHello(event){
        alert(event.data.firstname);//event handler has a data property by using which we can fetch the data(firstname, lastname, company)
        alert(event.data.lastname);
        alert(event.data.company);
    }
});