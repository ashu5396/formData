// var modal = document.querySelector("#modal");
// var modalOverlay = document.querySelector("#modal-overlay");
// var closeButton = document.querySelector("#close-button");
// var openButton = document.querySelector("#open-button");

// closeButton.addEventListener("click", function() {
//   modal.toggle();
//   modalOverlay.toggle();
// });

// openButton.addEventListener("click", function() {
//   modal.classList.toggle();
//   modalOverlay.classList.toggle();
// });





//this is my way of writing jquery code

$(document).ready(function(){
    $('#open-button').click(function(){
       callToggleFunction();
    })
    $('#close-button').click(function(){
        callToggleFunction();
       
    })
    $('#okay-button').click(function(){
       callToggleFunction();
        
    })

    var callToggleFunction=function(){
        $('#modal').toggle();
        $('#modal-overlay').toggle();
    }
    
})