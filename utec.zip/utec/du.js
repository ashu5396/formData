$(document).ready(function(){
    $('.book-service-button').click(function(){
       callToggleFunction();
    })
    $('#close-button').click(function(){
        callToggleFunction();
       
    })
    $('#okay-button').click(function(){
       callToggleFunction();
        
    })

    var callToggleFunction=function(){
        $('#modal').toggle();
        $('#modal-overlay').toggle();
    }

    $('.accordion-down-image').click(function(){
        $('#accordion').toggle()
       
    })
    
})