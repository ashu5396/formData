$(document).ready(function(){
  $('#designAccordion-icon-up').hide();
    $('#designAccordion-icon-down').click(function(){
      $('#designAccordion-icon-down').hide()
      $('#designAccordion-icon-up').show()
      $('#designAccordion').toggle();

    });
    $('#designAccordion-icon-up').click(function(){
      $('#designAccordion-icon-up').hide()
      $('#designAccordion-icon-down').show()
      $('#designAccordion').toggle();
      
    });
  });


  


