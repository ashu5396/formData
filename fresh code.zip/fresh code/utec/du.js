$(document).ready(function(){
    $('.book-service-button').click(function(){
       callToggleFunction();
    })
    $('#close-button').click(function(){
        callToggleFunction();
       
    })
    $('#okay-button').click(function(){
       callToggleFunction();
        
    })

    var callToggleFunction=function(){
        $('#modal').toggle();
        $('#modal-overlay').toggle();
    }

    $('.accordion-down-image').click(function(){
        $('#accordion').toggle()
        $('.accordion-down-image').hide();
        $('.accordion-up-image').show();
       
    })
    $('.accordion-up-image').click(function(){
        $('#accordion').toggle()
        $('.accordion-up-image').hide();
        $('.accordion-down-image').show();
       
    })
    
})