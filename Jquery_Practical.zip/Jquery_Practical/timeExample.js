$(document).ready(function(){
    $('#timeFinder').change(function(){
      
       $('#timeFinder option:selected').each(function(){
            
        var result='';
        if($(this).val()=="nowtimeis")
            {
                var result=new Date();
            }
        
         else if($(this).val()=="nexttfhours")
            {
                var milliseconds = new Date().getTime() + (24 * 60 * 60 * 1000);
               
                var result=new Date(milliseconds);
            }
            else if($(this).val()=="nextweek"){
                var milliseconds = new Date().getTime() + (24*7 * 60 * 60 * 1000);
               
                var result=new Date(milliseconds);

            }
            else if($(this).val()=="nextmonth"){
                var result=nextMonth();

            }
            else if($(this).val()=="nextthreemonth"){
                var result=nextThreeMonth();

            }
            else 
            {
                var result='<b style="color:red;">*</b><bold style="color:red;">Please Select Time</bold>'

            }
            
            $('#output').html('<div class="container"><b>'+result+'</b></div>');
       });
      
    });
    
});