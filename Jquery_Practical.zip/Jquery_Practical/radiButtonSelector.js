$(document).ready(function(){
    $('#buttn').click(function(){
        var result=$('input[type="radio"]:checked');
        if(result.length>0){
            $('#output').html("<h1>"+result.val()+" is Checked</h1>");
        }
        else{
            $('#output').html("<h1>Radio Button is not Checked</h1>");
        }
    });
});