$(document).ready(function(){
    $('#btn').click(function(){
        var result=$('input[type="checkbox"]:checked');
        if(result.length>0){
            $('#output').html("<h1>"+result.val()+" is Checked</h1>");
        }
        else{
            $('#output').html("<h1>Checkbox is not Checked</h1>");
        }
    });
});